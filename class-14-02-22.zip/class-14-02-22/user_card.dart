import 'package:flutter/cupertino.dart';

class UserCard{
  IconData icon;
  String title='';
  String subTitle='';
  String amount='';

  UserCard(this.icon,this.title,this.subTitle,this.amount);

}