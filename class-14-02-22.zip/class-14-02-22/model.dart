class User{
  String name="";
  int age=0;
  String profession='';

  User({this.name='',this.age=0,this.profession=''});
}