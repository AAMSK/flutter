import 'package:flutter/material.dart';
import 'user_card.dart';

List<UserCard> users=[
  UserCard(Icons.arrow_upward,"Sent","Sending Payment to client","150"),
  UserCard(Icons.arrow_downward,"Recieve","Recieving salary from company","250"),
  UserCard(Icons.local_atm,"Laon","Loan for the car","400"),
  UserCard(Icons.arrow_upward,"Sent","Sending Payment to client","150"),
  UserCard(Icons.arrow_downward,"Recieve","Recieving salary from company","250"),
  UserCard(Icons.local_atm,"Laon","Loan for the car","400"),
];